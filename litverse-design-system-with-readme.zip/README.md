# 📚 Litverse Design System

A best-in-class design system scaffold optimized for **Cursor IDE** development.  
Built with modular CSS, vanilla JS, accessibility by default, and `.cursorrules` protection.

---

## 🚀 Features
- 🎨 **Design Tokens** (colors, typography, spacing, shadows)
- 🧩 **Components** (buttons, cards, pills, chat bubbles, ratings, tables, etc.)
- 🌗 **Themes** (light, dark, high-contrast)
- ⚡ **Performance** (vanilla JS, minimal dependencies)
- ♿ **Accessibility** (WCAG 2.1 AA, focus rings, skip links)
- 🛡 **Cursor Protection** via `.cursorrules`

---

## 📂 Project Structure
```
litverse-design-system/
├─ .cursorrules
├─ package.json
├─ vite.config.js
├─ index.html                # Component showcase
├─ src/
│  ├─ main.js
│  ├─ js/
│  │   ├─ sys-core.js
│  │   ├─ sys-theme.js
│  │   ├─ sys-components.js
│  │   └─ sys-a11y.js
│  ├─ css/
│  │   ├─ tokens.css
│  │   ├─ themes.css
│  │   ├─ utilities.css
│  │   ├─ layout.css
│  │   ├─ components.css
│  │   └─ motion.css
│  └─ templates/
│      ├─ library.html
│      ├─ dashboard.html
│      ├─ blog.html
│      ├─ chat.html
│      └─ reader.html
```

---

## 🖥️ Setup Instructions

### Windows
1. Download and unzip this repo:  
   e.g. `C:\Users\<yourname>\Projects\litverse-design-system`
2. Open **PowerShell** and run:
   ```powershell
   cd "C:\Users\<yourname>\Projects\litverse-design-system"
   git init
   git add .
   git commit -m "Initial commit – Litverse Design System"
   ```

### macOS / Linux
```bash
cd ~/Projects/litverse-design-system
git init
git add .
git commit -m "Initial commit – Litverse Design System"
```

---

## ⬆️ Push to GitHub

1. Create a new repo on GitHub (no README).  
2. Copy the URL and run:
   ```bash
   git remote add origin https://github.com/YOURNAME/litverse-design-system.git
   git branch -M main
   git push -u origin main
   ```

---

## 📦 Usage in Projects

- **Option A**: Clone the repo each time:
  ```bash
  git clone https://github.com/YOURNAME/litverse-design-system.git
  ```

- **Option B**: Add as a submodule inside another project:
  ```bash
  git submodule add https://github.com/YOURNAME/litverse-design-system.git src/design-system
  ```

- **Option C**: Publish privately to npm and install like a package.

---

## ✅ Best Practices
- Use **tokens** (never hardcode hex values).  
- Use **`.sys-` prefixed classes** only.  
- Extend via utilities or custom overrides, not by editing `tokens.css`.  
- Tag versions when stable:
  ```bash
  git tag v1.0
  git push origin v1.0
  ```

---

## 📖 Templates Included
- **Library** → book listings + ratings  
- **Dashboard** → KPIs, charts, billing table, calendar  
- **Blog** → blog layout with sidebar widgets  
- **Chat** → chat messaging UI  
- **Reader** → reading view with sticky audio player  

---

## ⚡ Development
Run locally with Vite:
```bash
npm install
npm run dev
```

---

## 👤 Author
Built for future projects with **Cursor IDE** integration.
